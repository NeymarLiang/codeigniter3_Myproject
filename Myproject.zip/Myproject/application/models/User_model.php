<?php

class User_model extends CI_Model {
    function insertuser($data) {
        $this->db->insert('account', $data);
    }

    function insertbook($data) {
        $this->db->insert('books', $data);
    }

    function checkPassword($password,$username){
        $query = $this->db->query("SELECT * FROM account WHERE password='$password' AND username ='$username'");

        if($query->num_rows()==1){
            return $query->row();
        }else{
            return false;
        }
    }

    function getBooks(){
        $query = $this->db->get('books');
        return $query->result_array();
    }

    function getBook($id){
        $this->db->where('id',$id);
        $query = $this->db->get('books');
        return $query->row();
    }

    function updateBook($data, $id){
        $this->db->where('id',$id);
        $this->db->update('books', $data);

        if($this->db->affected_rows() >= 0){
            return true;
        }else{
            return false;
        }
    }

    function deleteBook($id){
        $this->db->where('id',$id);
        $this->db->delete('books');
        if($this->db->affected_rows() >= 0){
            return true;
        }else{
            return false;
        }
    }
}
