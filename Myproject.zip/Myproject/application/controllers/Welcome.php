<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('user_model');
	}
	

	public function index()
	{	
		$this->load->view('zRegister');
	}

	function registerNow(){  
		if($_SERVER['REQUEST_METHOD']=='POST'){
			$this->form_validation->set_rules('username','Username','required');
			$this->form_validation->set_rules('password','Password','required');
			$this->form_validation->set_rules('name','Name','required');

			if($this->form_validation->run()==TRUE){
				$userName = $this->input->post('username');
				$password = $this->input->post('password');
				$name = $this->input->post('name');

				$data = array(
					'userName'=> $userName,
					'password'=>$password,
					'name'=>$name,
				);

				$this->load->model('user_model');
				$this->user_model->insertuser($data);
				$this->session->set_flashdata('success','Successfully User Created');
				redirect(base_url('welcome/login'));
			}
		}
	}

	function login(){
		$this->load->view('zLogin');
	}

	function loginNow(){
		if($_SERVER['REQUEST_METHOD']=='POST'){
			$this->form_validation->set_rules('username','Username','required');
			$this->form_validation->set_rules('password','Password','required');
			
			if($this->form_validation->run()==TRUE){
				$username = $this->input->post('username');
				$password = $this->input->post('password');

				$this->load->model('user_model');
				$status = $this->user_model->checkPassword($password,$username);
				if($status!=false){
					$username = $status->username;
					$password = $status->password;

					$session_data = array(
						'userName'=>$username,
						'password'=>$password,
					);

					$this->session->set_userdata('UserLoginSession',$session_data);
					
					redirect(base_url('welcome/list'));
				}else{
					$this->session->set_flashdata('error', 'Email or Password is Wrong');
					redirect(base_url('welcome/login'));

				}

			}else{
				$this->session->set_flashdata('error','Fill in the blank');
				redirect(base_url('Welcome/login'));
			}

		}
	}

	function dashboard(){
		$this->load->view('dashboard');
	}

	function pic(){
		$this->load->view('hajimi.jpg');
	}

	function addBooks() {
		$this->load->library('form_validation');
		$this->load->library('upload');
		$config = array(
			'upload_path' => './uploads/', 
			'allowed_types' => 'jpg|jpeg|png'
		);

		$this->upload->initialize($config);

		if ($_SERVER['REQUEST_METHOD'] == "POST") {
			$this->form_validation->set_rules('bookname', 'Book Name', 'required');
			$this->form_validation->set_rules('author', 'Author', 'required');
	
			if ($this->form_validation->run() == false || !$this->upload->do_upload('image')) {
				$this->session->set_flashdata('error', validation_errors());
				redirect(base_url('welcome/dashboard'));
			} else {
				$bookname = $this->input->post('bookname');
				$author = $this->input->post('author');
				$image_data = $this->upload->data();
	
				$data = array(
					'bookname' => $bookname,
					'author' => $author,
					'image' => $image_data['file_name'],
				);
	
				$status = $this->user_model->insertbook($data);
				if ($status == true) {
					$this->session->set_flashdata('success', 'Successfully added');
					redirect(base_url('welcome/dashboard'));
				} else {
					$this->session->set_flashdata('error', validation_errors());
					redirect(base_url('welcome/dashboard'));
				}
			}
		} else {
			redirect(base_url('welcome/login'));
		}
	}

	function list() {
		$data['books'] = $this->user_model->getBooks();
		$this->load->view('booklist', $data);
	}
	
	function edit($id){

		$this->load->library('upload');
		$config = array(
			'upload_path' => './uploads/', 
			'allowed_types' => 'jpg|jpeg|png'
		);
		$this->upload->initialize($config);

        $data['book'] = $this->user_model->getBook($id);
        $data['id']=$id;
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $bookname = $this->input->post('bookname');
			$author = $this->input->post('author');
			
			if(!empty($_FILES['new_image']['name'])){
				if($this->upload->do_upload('new_image')){
					$image_data = $this->upload->data();
					$data['image'] = $image_data['file_name'];
				}else{
					$this->session->set_flashdata('error', $this->upload->display_errors());
					redirect(base_url('welcome/edit/' . $id));
				}
			}

            $data = array(
                'bookname' => $bookname,
                'author' => $author,
				'image' => isset($data['image']) ? $data['image'] : $data['book']->image,
            );

            $status =  $this->user_model->updateBook($data, $id);
            if ($status == true) {
                $this->session->set_flashdata('success', 'Successfully Updated');
				redirect(base_url('welcome/list'));
                // redirect(base_url('welcome/edit/'.$id));
            } else {
                $this->session->set_flashdata('error', 'Error');
                redirect(base_url('welcome/list'));
            }
        }else{
			$this->load->view('edit_book', $data);
        	//redirect(base_url('welcome/list'));
		}
    }

	function delete($id)
    {
        if(is_numeric($id))
        {
            $status =$this->user_model->deleteBook($id);
            if ($status == true) {
                $this->session->set_flashdata('deleted', 'successfully Deleted');
                redirect(base_url('welcome/list'));
            } else {
                $this->session->set_flashdata('error', 'Error');
                redirect(base_url('welcome/list'));
            }
        }
    }

	// function edit($id) {
	// 	$data['books'] = $this->user_model->getBook($id);
	// 	if ($_SERVER['REQUEST_METHOD'] == "POST") {
	// 		$bookname = $this->input->post('bookname');
	// 		$author = $this->input->post('author');
	
	// 		$dataToUpdate = array(
	// 			'bookName' => $bookname,
	// 			'auth' => $author,
	// 		);
	
	// 		$status = $this->user_model->updateBook($dataToUpdate, $id);
	// 		if ($status) {
	// 			$this->session->set_flashdata('success', 'Book Updated Successfully');
	// 			redirect(base_url('welcome/edit_book' . $id));
	// 		} else {
	// 			$this->session->set_flashdata('error', 'Failed to Update Book');
	// 			redirect(base_url('welcome/edit_books' . $id)); // Redirect with the error message
	// 		}
	// 		redirect(base_url('welcome/edit_book/' . $id));
	// 	}
		
	// 	//redirect(base_url('welcome/edit_book'. $id));
	// }
	
}

