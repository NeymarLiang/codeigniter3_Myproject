<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://cdn.datatables.net/v/bs5/dt-1.13.6/datatables.min.css" rel="stylesheet">
 
    <style type="text/css">
        body{
            background-color: #F7F7F7;
        }

        .container{
            margin-top: 130px;
            width: 1200px;
        }

        .btn.btn-primary.btn-sm {
            margin-left: 20px;
            text-decoration: none;
            font-size: 19px;
        }

        .card-title{
            margin-bottom: 15px;
            font-weight: bold;
            font-size: 30px;
        }

        .card{
            border-radius: 2.25rem
        }
    </style>
    <title>Add Books</title>
  </head>
  <body>
    <div class ="container">
        <div class="row">
            <div class="card" >
                <div class="card-body">
                    <p class="card-title text-center">Add Book</p>
                    <form method="post" action="<?=base_url('Welcome/addBooks')?>" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="bookname" class="form-label">Book Name</label>
                            <input type="text" name="bookname" class="form-control" id="bookname" placeholder="Book Name">
                            
                        </div>
                        <div class="mb-3">
                            <label for="author" class="form-label">Author</label>
                            <input type="text" class="form-control" id="author" name="author" placeholder="Author">
                        </div>
                        <div class="mb-3">
                            <label for="img" class="form-label">Image</label>
                            <input type="file" class="form-control" id="image" name="image" placeholder="Image">
                        </div>
                        <br>
                        <center>
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="<?= base_url('welcome/list') ?>" class="btn btn-sm btn-primary">Back</a><br>
                        </center>  
                        <br>  
                    </form>
                    <?php if($this->session->flashdata('error')) { ?>
                        <div class="alert alert-danger" role="alert">
                            Failed
                        </div>
                    <?php } ?>

                    <?php if($this->session->flashdata('success')) { ?>
                        <div class="alert alert-success" role="alert">
                            Successfully
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    

    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/v/bs5/dt-1.13.6/datatables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script type="text/javascript">
        $('#datatable').DataTable({
        });
    </script>
  </body>
</html>
<!-- <?php
    if($this->session->userdata('UserLoginSession')){
        
    }else{
        redirect(base_url('welcome/zLogin'));
    }
?> -->