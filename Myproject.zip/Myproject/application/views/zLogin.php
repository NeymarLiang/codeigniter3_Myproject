<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<style>
		body{
			margin:0px;
			display: flex;
            justify-content: center;
            align-items: center;
            background-color: #F7F7F7;
		}

		.loginPanel{
			    position: absolute;
			    top: 20%;
			    left: 26%;
			    width: 813px;
			    height: 474px;
			    border-radius: 7px;
			    background-color: white;
			    box-shadow: 5px 10px;
			    border: 1px solid;
		}

		.username{
			margin-top: 10px;
			border-radius: 5px;
			border: 1px gray solid;
			height: 30px;
			width: 300px;
			text-align: center;
		}

		.password{
			margin-top: 15px;
			border-radius: 5px;
			border: 1px gray solid;
			height: 30px;
			width: 300px;
			text-align: center;
		}

		.register{
			cursor: pointer;
			font-family: system-ui;
			width: 141px;
			margin-top: 5px;
		}

		.submit{
			margin-top: 15px;
			font-family: system-ui;
			border-radius: 5px;
			border: 0px gray solid;
			background-color: transparent;
			color: black;
			cursor: pointer;
			font-size: 17px;

		}

		.register:hover {
		    color: gray;
		}

		.submit:hover{
			color: gray;
		}

		.content{
			display: flex;
		}

		.left{
			height: auto;
			flex: 1;
		}

		.right{
			flex: 1;
		}

		.hajimi{
			width: 408px;
    		height: 474px;
			border-radius: 5px;
		}

		.login{
			font-size: 50px;
			font-weight: bold;
			font-family: system-ui;
		}

		.register{
			text-decoration: none;
			color:black;
		}

	</style>
</head>
<body>
	<center>
	<div class="loginPanel">
		<div class="content">
			<div class="left">
				<img src="<?= base_url('uploads/hajimi.jpg') ?>" class="hajimi">
			</div>
			<div class="right">
				<form method="post" action="<?=base_url('welcome/loginNow')?>">
					<p class="login">Login</p>
					<input type="text" name="username" class="username" placeholder="Username"><br>
					<input placeholder="Password" type="password" name="password" class="password"><br>
					<input type="submit" value="LOGIN" class="submit">
					<a name="register" class="register" href="<?= base_url('welcome/index')?>">REGISTER</a>
				</form>
			</div>
		</div>
	</div>
	</center>
</body>
</html>

<?php
	if($this->session->flashdata('success')){ ?>
		<p class='text-success text-center' > <?=$this->session->flashdata('success')?></p>
<?php } ?>

<script>
	function register(){
		window.location.assign("Myproject/views/zRegister.php");
	}
</script>