<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://cdn.datatables.net/v/bs5/dt-1.13.6/datatables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <style type="text/css">
        .container{
            margin-top: 25px;
            margin-bottom: 30px;
        }

        .table{
            text-align: center; 
            vertical-align: middle;
        }

        .btn1{
            color: white;
            text-decoration: none;
            margin-left: 1185px;
        }

        .card-title{
            margin-bottom: 15px;
            font-weight: bold;
            font-size: 30px;
        }

        .img{
            height:110px;
            width: 80px;
        }

        body{
            background-color: #F7F7F7;
        }

        .card{
            border-radius: 2.25rem
        }
    </style>
    <title>BookList</title>
  </head>
  <body>
    <div class ="container">
    <p class="card-title text-center">Book List</p>
        <div class="row">
            <div class="card" >
                <div class="card-body">
                    <table class="table table-bordered" id="table">
                        <thead>
                            <tr>
                                <th>Book ID</th>
                                <th>Image</th>
                                <th>Book Name</th>
                                <th>Author</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i=1; foreach($books as $row){ ?>
                            <tr>
                                <td><?=$row['id']?></td>
                                <td><img src="<?= base_url('uploads/'.$row['image']) ?>" alt="Book Image" class="img"></td>
                                <td><?=$row['bookname']?></td>
                                <td><?=$row['author']?></td>
                                <td>
                                <a href="<?= base_url()?>welcome/edit/<?=$row['id']?>" class="btn btn-sm btn-primary">Edit</a>
                                </td>
                                <td><a href="<?=base_url()?>welcome/delete/<?=$row['id']?>" class="btn btn-sm btn-danger as">Delete</a></td>
                            </tr>
                            <?php }?>
                        </tbody>
                        <a href="<?= base_url('welcome/dashboard') ?>" class="btn1 btn-sm btn-primary">Add Book</a><br>
                        <p></p>
                    </table>
                    <?php if($this->session->flashdata('error')) { ?>
                        <div class="alert alert-danger" role="alert">
                            Failed
                        </div>
                    <?php } ?>

                    <?php if($this->session->flashdata('success')) { ?>
                        <div class="alert alert-success" role="alert">
                            Successfully
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/v/bs5/dt-1.13.6/datatables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

    
    <script>
        $(document).ready(function(){
            $('#table').DataTable();
        });
    </script>
  </body>
</html>