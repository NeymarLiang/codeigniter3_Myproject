<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Register</title>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js">
	<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://cdn.datatables.net/v/bs5/dt-1.13.6/datatables.min.css" rel="stylesheet">
	</script>
	<style type="text/css">
		body{
			margin: 0px;
			background-color: #75E2E9;
		}

		.register{
			margin-top: 15%;
			border: 1px white solid;
			width: 22%;
			border-radius: 10px;
			background-color: white;
			height: 339px;
			box-shadow: 5px 10px;
		}

		.username{
			border-radius: 5px;
			margin-top: 10px;
			margin-bottom: 15px;
			height: 25px;
			width: 200px;
			padding: 5px;
			text-align: center;
		}

		.password{
			margin-bottom: 15px;
			height: 25px;
			width: 200px;
			border-radius: 5px;
			padding: 5px;
			text-align: center;
		}

		.submit{
			margin-bottom: 15px;
		}

		.name{
			border-radius: 5px;
			margin-top: 10px;
			margin-bottom: 10px;
			height: 25px;
			width: 200px;
			padding: 5px;
			text-align: center;
		}

		.re{
			font-size: 30px;
			font-weight: bold;
			margin-bottom: 10px;
			color: #6DA8D2;
			font-family: "Gill Sans", sans-serif;
		}

		.submit{
			font-size: 15px;
			border-radius: 5px;
			height: 25px;
			background: #3786BE;
			color: white;
			border: 0px;
			width: 70px;
			cursor: pointer;
			margin-right: 10px;
		}

		.back{
			font-family: "Gill Sans", sans-serif;
			font-size: 17px;
			border-radius: 5px;
			padding: 3px 7px;
			height: 25px;
			background: #3786BE;
			color: white;
			border: 0px;
			width: 70px;
			cursor: pointer;
			margin-bottom: 40px;
			text-decoration: none;
		}

		back:link, back:visited {
			background-color: #3786BE;
			color: white;
			padding: 14px 25px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
		}

		.submit:hover{
			filter: brightness(80%);
		}

		.back:hover{
			filter: brightness(80%);
		}



	</style>
</head>
<body>
	<center>
	<div class="register">
		<form method="post" autocomplete="off" action="<?=base_url('welcome/registerNow')?>">
			<p class="re">REGISTER</p>
			<input type="text" name="name" class="name" class="name" placeholder="Name"><br>
			<input class="username" name="username" placeholder="Username" type="text"><br>
			<input type="password" name="password" class="password" placeholder="Password"><br>
			<input type="submit" name="submit" value="Register" class="submit">
		</form>
		<a href="<?= base_url('welcome/login') ?>" class="back">Back to Login</a>
	</div>
	</center>
</body>
</html>

<?php
	// include 'zDatabase.php';

	// if (isset($_POST['back'])) {
	// 	header('Location: zLogin.php');
	// }

	// if (isset($_POST['submit'])) {
	// 	$username = $_POST['username'];
	// 	$password = $_POST['password'];
	// 	$name = $_POST['name'];

	// 	$sql = "SELECT username FROM account WHERE username = '$username'";
	// 	$result = mysqli_query($mysqli, $sql);

	// 	if($username ==""||$password ==""||$name ==""){
	// 		echo "<script>alert('Fill in the blank')</script>";
	// 	}else if(strlen($username)<0||strlen($password)<0){
	// 		echo "<script>alert('username and password must enter 8-12 characters')</script>";
	// 	}else if(mysqli_num_rows($result) > 0){
	// 		echo "<script> alert('Username already exists. Please choose a different username.')</script>";
	// 	}else{
	// 		$sql = "INSERT INTO account(userName, password,name)
	// 				VALUES ('$username', '$password', '$name')
	// 		";

	// 		if (mysqli_query($mysqli, $sql)) {
	// 	        echo "<script>
	// 		            alert('Register Successfully');
	// 		            window.location.assign('zLogin.php');
	// 		        </script>
	// 	        ";
	// 	    }
	// 	}

	// }
?>

<?php
	if($this->session->flashdata('success')){ ?>
		<p class='text-success text-center' > <?=$this->session->flashdata('success')?></p>
<?php } ?>


